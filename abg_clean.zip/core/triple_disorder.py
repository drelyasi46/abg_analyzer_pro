"""
triple_disorder.py

Triple Acid-Base Disorder Detection
"""


class TripleDisorderDetector:


    @staticmethod
    def evaluate(
        primary_disorder,
        mixed_result=None,
        delta_ratio=None,
    ):
        """
        Detect possible triple acid-base disorders.
        """


        findings = []


        # Mixed respiratory + metabolic disorder

        if mixed_result:

            if "Mixed Disorder Detected" in mixed_result:

                findings.append(
                    mixed_result
                )


        # Delta-Delta abnormality suggesting
        # additional metabolic disorder

        if delta_ratio is not None:


            if delta_ratio > 2:

                findings.append(
                    "Additional Metabolic Alkalosis suspected"
                )


            elif delta_ratio < 0.4:

                findings.append(
                    "Additional Normal Anion Gap Metabolic Acidosis suspected"
                )


        # Final interpretation

        if len(findings) >= 2:

            return (
                "TRIPLE DISORDER DETECTED\n"
                "-------------------------\n"
                + "\n".join(findings)
            )


        elif len(findings) == 1:

            return findings[0]


        else:

            return None